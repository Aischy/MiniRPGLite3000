package com.isep.rpg;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FighterTest {
    @Test
    public void testCorrectLife() throws Exception {
        int life = 40;
        Fighter fighter = new Fighter("test",life);
        assertEquals(40,40);
    }
}
