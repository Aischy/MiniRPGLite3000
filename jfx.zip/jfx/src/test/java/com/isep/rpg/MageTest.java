package com.isep.rpg;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MageTest {
    @Test
    public void testCorrectMana() throws Exception {
        Mage test = new Mage("test","healer");
        test.setMana(35);
        assertEquals(35,test.getMana());
    }
}
