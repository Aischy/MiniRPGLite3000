package com.isep.rpg;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HealerTest {
    @Test
    public void testCorrectMana() throws Exception {
        Healer test = new Healer("test","healer");
        test.setMana(35);
        assertEquals(35,test.getMana());
    }
}
