package com.isep.rpg;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class WarriorTest {
    @Test
    public void testCorrectCharge() throws Exception {
        Warrior test = new Warrior("test","warrior");
        test.setCharge(30);
        assertEquals(30,test.getCharge());
    }
}
