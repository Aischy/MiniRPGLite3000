package com.isep.rpg;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HeroTest {
    @Test
    public void testCorrectAddPV() throws Exception {
        Food gambas = new Food(20);
        assertEquals(20,gambas.getAddPV());
    }
}
