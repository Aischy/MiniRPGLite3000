package com.isep.rpg;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PotionTest {
    @Test
    public void testCorrectAddMana() throws Exception {
        Potion potion = new Potion(20);
        assertEquals(20,potion.getAddMana());
    }
}
