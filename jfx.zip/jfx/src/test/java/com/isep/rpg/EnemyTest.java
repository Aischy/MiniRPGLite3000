package com.isep.rpg;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class EnemyTest {
    @Test
    public void testCorrectArmor() throws Exception {
        BasicEnemy enemy = new BasicEnemy(40,5,10,"enemy");
        enemy.setArmor(35);
        assertEquals(35,enemy.getArmor());
    }
}
