package com.isep.rpg;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HunterTest {
    @Test
    public void testCorrectArrows() throws Exception {
        Hunter test = new Hunter("test","healer");
        test.setArrows(35);
        assertEquals(35,test.getArrows());
    }
}
