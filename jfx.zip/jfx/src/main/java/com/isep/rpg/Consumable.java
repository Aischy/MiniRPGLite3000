package com.isep.rpg;

public class Consumable {

}
