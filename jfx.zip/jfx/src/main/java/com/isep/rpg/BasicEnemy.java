package com.isep.rpg;

public class BasicEnemy extends Enemy{


    //Constructeur
    public BasicEnemy(int lifePoints, int armor, int weaponDamage,String name) {
        super(lifePoints, armor, weaponDamage,name);
    }



    //Fonctions

}
