package com.isep.rpg;

public class Boss extends Enemy{
    //Attribut
    //Créa d'un coup spécial ou ajout de vie/armor/damage par rapport aux BasicEnemy

    //Constructeur
    public Boss(int lifePoints, int armor, int weaponDamage,String name) {
        super(lifePoints, armor, weaponDamage,name);
    }


    //Fonctions actions

}
