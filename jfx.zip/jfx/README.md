# Mini RPG Lite 3000 - Capucine Barre

Mini RPG Lite 3000 est un jeu developpe par Capucine Barre dans le cadre des cours de JAVA en A1 a l'ISEP. 
Ce RPG possede 2 interfaces : une interface graphique avec un jeu extremement limite ; une interface console tres developpe. 

# Interface graphique
Dans cette interface graphique, vous incarnez un mage qui doit combattre un monstre. 
En cliquant sur les boutons Sort ou Incantation, vous pourrez infliger des dommages au monstre. 
Cette interface n'ayant ete que peu developpee, elle est tres limitee. 

Avantages : Actions faciles a realiser, visuel agreable. 

Desavantages : Vous ne pourrez choisir ni votre nom, ni votre classe, ni le nombre de joueur. Il n'y a qu'un combat possible mais il n'y a pas de fin a ce combat. 


# Interface console
Dans cette interface, vous pourrez jouer a plusieurs et incarner la classe de votre choix (Hunter, Healer, Mage, Warrior). 
Vous pourrez combattre des monstres et suivant les combats des boss. 
Apres chaque combat, vous pourrez choisir une recompense et augmenter votre score. 
Si votre objectif est d'avoir le meilleur score possible, alors a vous de jouer !!!
Mais si votre but est de gagner, alors je vous conseille de vous interesser scrupuleusement au code. La resolution du jeu s'y trouve ! ;)

Avantages : choix du nombre de joueurs, du nom, de la classe, de nombreux combats contre des monstres et des boss, des recompenses, une histoire et une veritable fin de partie. 

Desavantages : Visuel en console, extremement basique (texte). 


# Autre : tests unitaires
Vous pourrez trouver les tests unitaires de toutes les classes necessaires dans le dossier Test. 

# Sur ce, bon jeu !"# MiniRPGLite3000" 
